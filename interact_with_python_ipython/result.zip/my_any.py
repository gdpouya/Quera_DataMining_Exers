# coding: utf-8
def my_any(x):
    for item in x:
        if item :
            return True
    return False
